// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xproject.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XProject_CfgInitialize(XProject *InstancePtr, XProject_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XProject_Start(XProject *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XProject_IsDone(XProject *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XProject_IsIdle(XProject *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XProject_IsReady(XProject *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XProject_EnableAutoRestart(XProject *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XProject_DisableAutoRestart(XProject *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_AP_CTRL, 0);
}

void XProject_InterruptGlobalEnable(XProject *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_GIE, 1);
}

void XProject_InterruptGlobalDisable(XProject *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_GIE, 0);
}

void XProject_InterruptEnable(XProject *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_IER);
    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_IER, Register | Mask);
}

void XProject_InterruptDisable(XProject *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_IER);
    XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XProject_InterruptClear(XProject *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XProject_WriteReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_ISR, Mask);
}

u32 XProject_InterruptGetEnabled(XProject *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_IER);
}

u32 XProject_InterruptGetStatus(XProject *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XProject_ReadReg(InstancePtr->Control_BaseAddress, XPROJECT_CONTROL_ADDR_ISR);
}

